<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Pelanggan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Create Pelanggan
            <small>Data Pelanggan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('pelanggan.index')); ?>"><i class="fa fa-dashboard"></i> Pelanggan</a></li>
            <li class="active">Create</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-xs-6">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Pelanggan</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'pelanggan.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Nama Pelanggan</label>
                        <?php echo Form::text('namapel', null, array('placeholder' => 'Nama Pelanggan','class' =>
                        'form-control','autofocus')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">No Telp</label>
                        <?php echo Form::text('notelp', null, array('placeholder' => 'No Telepon / HP','class' =>
                        'form-control')); ?>

                    </div>
                    <div class="form-group">
                        <label for="password">Alamat</label>
                        <?php echo Form::text('alamat', null,array('placeholder' => 'Alamat Pelanggan','class' => 'form-control')); ?>

                    </div>
                    <div class="form-group">
                        <label for="confirm">Kode Promo</label>
                        <?php echo Form::select('promoid',$arrPromo, null, array
                        ('placeholder' => 'Pilih Kode Promo','class' =>'form-control')); ?>

                    </div>
                    <div class="form-group">
                        <label for="confirm">Jenis Pelanggan</label>
                        <?php echo Form::select('jenis_pelanggan',$arrJenisPelanggan, null, array
                        ('placeholder' => 'Pilih Tipe Pelanggan','class' =>'form-control')); ?>

                    </div>

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-default btn-flat">Kembali</a>
                    </div>
                </div>
            <?php echo Form::close(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>

    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        //Date picker
        $('#tglAmbil').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd"
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
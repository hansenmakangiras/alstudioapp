<div class="callout callout-info">
    <h4>Reminder!</h4>
    Instructions for how to use modals are available on the
    <a href="http://getbootstrap.com/javascript/#modals">Bootstrap documentation</a>
</div>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Promo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Update Promo
            <small>Data Promo</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('promo.index')); ?>"><i class="fa fa-dashboard"></i> Promo</a></li>
            <li class="active">Create</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-xs-6">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Ubah Promo</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::model($promo, ['method' => 'PATCH','route' => ['promo.update', $promo->id]]); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Kode Promo</label>
                        <?php echo Form::text('kode', $promo->kode, array('placeholder' => 'Kode Promo','class' =>
                        'form-control','readonly')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Nama Promo</label>
                        <?php echo Form::text('namapromo', null, array('placeholder' => 'Beri nama promo anda','class' =>
                        'form-control','autofocus')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Deksripsi Promo</label>
                        <?php echo Form::text('deskripsi', null, array('placeholder' => 'Jelaskan promo anda','class' =>
                        'form-control')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Promo Berakhir Tanggal</label>
                        <?php echo Form::date('expire_date', \Carbon\Carbon::now(),['class' =>'form-control date','id'=>'expireDate']); ?>

                        
                        
                    </div>
                    <div class="form-group">
                        <label for="confirm">Tipe Pelanggan</label>
                        <?php echo Form::select('tipe_pelanggan',$arrJenisPelanggan, null, array
                        ('placeholder' => 'Pilih Tipe Pelanggan','class' =>'form-control')); ?>

                    </div>
                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        <a href="<?php echo e(route('promo.index')); ?>" class="btn btn-default btn-flat">Kembali</a>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        //Date picker
        $('#expireDate').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd"
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
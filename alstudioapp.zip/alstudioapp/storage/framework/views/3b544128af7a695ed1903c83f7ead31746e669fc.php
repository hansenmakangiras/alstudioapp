<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subtitle'); ?>
    | Permission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Permission
            <small>Permission Management</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main row -->
    <div class="row">
        <div class="col-xs-4">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Add Permission</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'permissions.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <?php echo Form::text('name', null, array('placeholder' => 'Nama Ijin','class' => 'form-control',
                        'id'=>'name')); ?>

                    </div>
                    <div class="form-group">
                        <?php if(!$roles->isEmpty()): ?>
                            <label for="email">Assign Permissions to Roles : </label>
                            <?php echo e(Form::select('roles[]',$selectRoles,  null, [ 'class'=>'form-control select2',
                            'data-placeholder'=>'Pilih Ijin', 'style' => "width: 100%",'multiple' => 'multiple' ])); ?>

                        <?php endif; ?>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary btn-flat pull-right">Simpan</button>
                        
                            
                    </div>

                </div>
            <?php echo Form::close(); ?>

            <!-- /.box-body -->
            </div>
        </div>
        <div class="col-xs-8">
            <div class="box">
                <div class="box-header">
                    
                    
                        
                    
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-sm btn-flat"><i class="fa
                        fa-user-plus"></i> Pengguna</a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-success btn-sm btn-flat"><i class="fa
                        fa-user-secret"></i> Level Akses</a>
                    <?php endif; ?>
                    
                        
                            

                            
                                
                            
                        
                    
                </div>

                <div class="box-body">
                    <table id="tbl-permission" class="table table-hover">
                        <thead>
                        <tr>
                            <th width="50px">#</th>
                            <th>Permissions</th>
                            
                            <th width="100px">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($permission->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('permissions.edit',$permission->id)); ?>" class="btn btn-primary
                                btn-xs btn-flat">Edit</a>
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['permissions.destroy',
                                    $permission->id],
                                    'style'=>'display:inline']); ?>

                                    <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs btn-flat']); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer text-center">
                    <?php echo e($permissions->onEachSide(1)->links()); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $('#tbl-permission').DataTable({
            
            
            
                
                
            
            
                
                
                
                
                
                
                
                
            
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'autoWidth'   : true,
            "language": {
                "lengthMenu": "Tampilkan _MENU_ baris per page",
                "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
                // "info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "Data tidak tersedia",
                "infoFiltered": "(Filter dari _MAX_ total data)",
                "search" : "Pencarian",
                "paginate" : {
                    "first" : "Awal",
                    "last" : "Akhir",
                    "next" : "&gt;",
                    "previous" : "&lt;"
                }
            },
            "pagingType": "full_numbers",
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
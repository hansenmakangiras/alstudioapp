<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Jenis Bayar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Jenis Bayar
            <small>Master Data</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Jenis Bayar</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('status-bayar.create')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-plus-circle"></i> Tambah Jenis Bayar</a>
                </div>

                <div class="box-body">
                    <table id="tbl-status-bayar" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Jenis Bayar</th>
                            <th>Tgl Buat</th>
                            <th>Tgl Update</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $statusBayar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($val->statusbyr); ?></td>
                                <td><?php echo e($val->created_at); ?></td>
                                <td><?php echo e($val->updated_at); ?></td>
                                <td>

                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('status-bayar.show',$val->id)); ?>">View</a>
                                    

                                    <a href="<?php echo e(route('status-bayar.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    

                                        <?php echo Form::open(['method' => 'DELETE','route' => ['status-bayar.destroy', $val->id],
                                        'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                <?php echo e($statusBayar->onEachSide(1)->links()); ?>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $('#tbl-status-bayar').DataTable({
        
        
        
            
            
        
        
            
            
            
            
            
            
            
            
        
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'autoWidth'   : true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ baris per page",
            "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
            //"info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "Data tidak tersedia",
            "infoFiltered": "(Filter dari _MAX_ total data)",
            "search" : "Pencarian",
            "paginate" : {
                "first" : "Awal",
                "last" : "Akhir",
                "next" : "&gt;",
                "previous" : "&lt;"
            }
        },
        "pagingType": "full_numbers",
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
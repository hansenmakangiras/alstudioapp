<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Promo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Promo
            <small>Master Promo</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Promo</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('promo.create')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-plus-circle"></i> Tambah Promo</a>
                </div>

                <div class="box-body">
                    <table id="tbl-promo" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Deskripsi</th>
                            <th>Tgl Berakhir</th>
                            <th>Tipe Pelanggan</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($val->kode); ?></td>
                                <td><?php echo e($val->namapromo); ?></td>
                                <td><?php echo e($val->deskripsi); ?></td>
                                <td><?php echo e($val->expire_date); ?></td>
                                <td><?php echo \App\Models\Pelanggan::getJenisPelanggan
                                ($val->tipe_pelanggan); ?></td>
                                <td>
                                    
                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('promo.show',$val->id)); ?>">View</a>
                                    
                                    
                                    <a href="<?php echo e(route('promo.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    
                                    
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['promo.destroy', $val->id],
                                        'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                <?php echo e($promo->onEachSide(1)->links()); ?>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $('#tbl-promo').DataTable({
        
        
        
            
            
        
        
            
            
            
            
            
            
            
            
        
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'autoWidth'   : true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ baris per page",
            "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
            //"info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "Data tidak tersedia",
            "infoFiltered": "(Filter dari _MAX_ total data)",
            "search" : "Pencarian",
            "paginate" : {
                "first" : "Awal",
                "last" : "Akhir",
                "next" : "&gt;",
                "previous" : "&lt;"
            }
        },
        "pagingType": "full_numbers",
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
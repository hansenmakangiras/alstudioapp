<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2018-2020 <a href="https://adminlte.io">AL Studio</a>.</strong> All rights
    reserved.
</footer>

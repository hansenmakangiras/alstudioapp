<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Pelanggan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Data Pelanggan
            <small>Master Customer</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Pelanggan</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-plus-circle"></i> Tambah Pelanggan</a>
                </div>

                <div class="box-body">
                    <table id="tbl-pelanggan" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>No Telp</th>
                            <th>Kode Promo</th>
                            <th>Jenis Pelanggan</th>
                            <th>Status Pelanggan</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($val->namapel); ?></td>
                                <td><?php echo e($val->alamat); ?></td>
                                <td><?php echo e($val->notelp); ?></td>
                                <td><?php echo e(\App\Models\Promo::getKodePromoWithTipe($val->promoid,$val->jenis_pelanggan)); ?></td>
                                <td><?php echo \App\Models\Pelanggan::getJenisPelanggan
                                ($val->jenis_pelanggan); ?></td>
                                <td><label class="label bg-green"><?php echo e(\App\Models\Pelanggan::getStatusPelanggan
                                ($val->status)); ?></label></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("viewPelanggan")): ?>
                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('pelanggan.show',$val->id)); ?>">View</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editPelanggan')): ?>
                                    <a href="<?php echo e(route('pelanggan.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePelanggan')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pelanggan.destroy', $val->id],
                                        'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                <?php echo e($pelanggan->onEachSide(1)->links()); ?>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $('#tbl-pelanggan').DataTable({
        
        
        
            
            
        
        
            
            
            
            
            
            
            
            
        
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'autoWidth'   : true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ baris per page",
            "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
            //"info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "Data tidak tersedia",
            "infoFiltered": "(Filter dari _MAX_ total data)",
            "search" : "Pencarian",
            "paginate" : {
                "first" : "Awal",
                "last" : "Akhir",
                "next" : "&gt;",
                "previous" : "&lt;"
            }
        },
        "pagingType": "full_numbers",
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
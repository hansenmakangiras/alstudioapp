<?php $__env->startSection('extra-css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    Tambah Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Create Roles
            <small>Data Pengguna</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-6">
            <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Roles</h3>
                    
                        
                        
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control',
                        'id'=>'name')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Assign Permissions : </label>
                        
                            
                                
                            
                            
                        
                        <?php echo e(Form::select('permission',$permit,  null, [ 'class'=>'form-control select2',
                        'multiple' => 'multiple', 'data-placeholder'=>'Pilih Permission', 'style' => "width: 100%" ])); ?>

                        
                            
                                
                                    
                                    

                                    
                                    
                                
                            
                        
                    </div>

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-success btn-flat">Kembali</a>
                    </div>

                </div>
                <?php echo Form::close(); ?>

                <!-- /.box-body -->

            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
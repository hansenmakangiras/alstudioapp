<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Status Cetak
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Status Cetak
            <small>Master Data</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Status Cetak</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('status-cetak.create')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-plus-circle"></i> Tambah Status Cetak</a>
                </div>

                <div class="box-body">
                    <table id="tbl-status-cetak" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Status Cetak</th>
                            <th>Tgl Buat</th>
                            <th>Tgl Update</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $statusCetak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($val->statuscetak); ?></td>
                                <td><?php echo e($val->created_at); ?></td>
                                <td><?php echo e($val->updated_at); ?></td>
                                <td>

                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('status-cetak.show',$val->id)); ?>">View</a>
                                    

                                    <a href="<?php echo e(route('status-cetak.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    

                                        <?php echo Form::open(['method' => 'DELETE','route' => ['status-cetak.destroy',
                                        $val->id],
                                        'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                <?php echo e($statusCetak->onEachSide(1)->links()); ?>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $('#tbl-status-cetak').DataTable({
        
        
        
            
            
        
        
            
            
            
            
            
            
            
            
        
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'autoWidth'   : true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ baris per page",
            "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
            //"info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "Data tidak tersedia",
            "infoFiltered": "(Filter dari _MAX_ total data)",
            "search" : "Pencarian",
            "paginate" : {
                "first" : "Awal",
                "last" : "Akhir",
                "next" : "&gt;",
                "previous" : "&lt;"
            }
        },
        "pagingType": "full_numbers",
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
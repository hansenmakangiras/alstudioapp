<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Bahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Create Bahan
            <small>Master Bahan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('bahan.index')); ?>"><i class="fa fa-dashboard"></i> Bahan</a></li>
            <li class="active">Create</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-6">
            <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Bahan</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'bahan.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Nama Bahan</label>
                        <?php echo Form::text('nama_bahan', null, array('placeholder' => 'Nama Bahan','class' =>
                        'form-control','autofocus')); ?>

                    </div>
                    <div class="form-group">
                        <label for="satuanid">Jenis Satuan</label>
                        <?php echo Form::select('id_satuan',$satuan, null, array
                        ('placeholder' => 'Pilih Satuan','class' =>'form-control select2')); ?>

                    </div>
                    <div class="form-group">
                        <label for="bahan">Harga Satuan</label>
                        <?php echo Form::number('hpp',null,['placeholder' => 'Harga','class' => 'form-control','id'=>'bahan']); ?>

                    </div>

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        <a href="<?php echo e(route('bahan.index')); ?>" class="btn btn-default btn-flat">Kembali</a>
                    </div>
                </div>
            <?php echo Form::close(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        //Date picker
        // $('#tglAmbil').datepicker({
        //     autoclose: true,
        //     format: "yyyy-mm-dd"
        // })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
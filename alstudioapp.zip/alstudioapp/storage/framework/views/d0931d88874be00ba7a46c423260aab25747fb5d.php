<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Jenis Cetakan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Jenis Cetakan
            <small>Data Master</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-6">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Ubah Jenis Cetakan - <?php echo e($jenisCetakan->jenis_cetak); ?></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <!-- form start -->
                    <form role="form" method="POST" action="<?php echo e(route('jenis-cetak.update', $id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="modal-body">
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="jeniscetak">Kode Jenis</label>
                                    <input type="text" class="form-control" id="kodejenis"
                                           placeholder="Masukkan Kode Jenis" name="kode_jenis" value="<?php echo e($jenisCetakan->kode_jenis); ?>"
                                           required autofocus>
                                    
                                </div>
                                <div class="form-group">
                                    <label for="jeniscetak">Jenis Cetakan</label>
                                    <input type="text" class="form-control" id="jeniscetak"
                                           placeholder="Masukkan jenis cetakan" name="jenis_cetak" value="<?php echo e($jenisCetakan->jenis_cetak); ?>"
                                           required>
                                    
                                </div>
                                
                                    
                                    
                                           
                                     
                                    
                                
                                
                                    
                                    
                                           
                                    
                                     
                                    
                                
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <div class="modal-footer text-center">
                            <a href="<?php echo e(route('jenis-cetak.index')); ?>" class="btn btn-default"><i class="fa
                        fa-arrow-left"></i> Kembali</a>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Update</button>
                        </div>
                    </form>

                </div>
                <!-- /.box-body -->

            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
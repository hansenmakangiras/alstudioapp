<?php $__env->startSection('extra-css'); ?>
    <!-- DataTables -->
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    User List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Data Pengguna
            <small>Users Management</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("widget.alert", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
        
        
        
    
    <!-- Small boxes (Stat box) -->


    <!-- /.row -->
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-danger btn-sm"><i class="fa
                        fa-plus-circle"></i> Tambah Pengguna</a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary btn-sm"><i class="fa
                        fa-cog"></i> Manage Permission</a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-cog"></i> Manage Role</a>
                    <?php endif; ?>
                </div>
            <!-- /.box-header -->
                <div class="box-body">
                    <table id="tbl-user" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Level Akses</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($val->name); ?></td>
                                <td><?php echo e($val->username); ?></td>
                                <td><?php echo e($val->email); ?></td>
                                <td>
                                    <?php if(!empty($val->getRoleNames())): ?>
                                        <?php $__currentLoopData = $val->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="label bg-gray"><?php echo e($v); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if(auth()->check() && auth()->user()->hasRole("Superadmin")): ?>
                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('users.show',$val->id)); ?>">View</a>
                                    <?php endif; ?>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                                    <a href="<?php echo e(route('users.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    <?php endif; ?>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $val->id],
                                        'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>

        $('#tbl-user').DataTable({
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'autoWidth'   : true,
            "language": {
                "lengthMenu": "Tampilkan _MENU_ baris per page",
                "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
                //"info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "Data tidak tersedia",
                "infoFiltered": "(Filter dari _MAX_ total data)",
                "search" : "Pencarian",
                "paginate" : {
                    "first" : "Awal",
                    "last" : "Akhir",
                    "next" : "&gt;",
                    "previous" : "&lt;"
                }
            },
            "pagingType": "full_numbers",
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('extra-css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    Role List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Role
            <small>Data Roles</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-danger btn-sm"><i class="fa
                        fa-user-secret"></i> Add Roles</a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary btn-sm"><i class="fa
                        fa-cog"></i> Manage Permission</a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-user-plus"></i> Manage Users</a>
                    <?php endif; ?>
                </div>

                <div class="box-body">
                    <table id="tbl-role" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Roles</th>
                            
                            <th width="280px">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($role->name); ?></td>
                                
                                    
                                        
                                    
                                
                                <td>
                                    <a class="btn btn-info btn-xs" href="<?php echo e(route('roles.show',$role->id)); ?>">Show</a>

                                    <a href="<?php echo e(route('roles.edit',$role->id)); ?>" class="btn btn-primary
                                btn-xs">Edit</a>
                                    

                                    <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],
                                    'style'=>'display:inline']); ?>

                                    <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs']); ?>

                                    <?php echo Form::close(); ?>

                                    
                                    
                                
                                            
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bower_components/datatables.net-bs4/datatables.min.js')); ?>"></script>
    <script>

        $('#tbl-role').DataTable({
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'autoWidth'   : true,
            "language": {
                "lengthMenu": "Tampilkan _MENU_ baris per page",
                "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
                //"info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "Data tidak tersedia",
                "infoFiltered": "(Filter dari _MAX_ total data)",
                "search" : "Pencarian",
                "paginate" : {
                    "first" : "Awal",
                    "last" : "Akhir",
                    "next" : "&gt;",
                    "previous" : "&lt;"
                }
            },
            "pagingType": "full_numbers",
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
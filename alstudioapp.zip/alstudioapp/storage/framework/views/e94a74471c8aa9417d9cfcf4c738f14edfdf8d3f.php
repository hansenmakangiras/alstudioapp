<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    Detail Status Bayar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Show Jenis Bayar
            <small>Data Jenis Bayar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">List Jenis Bayar</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Detail Jenis Bayar</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Jenis Bayar</label>
                        <?php echo Form::text('statusbyr', $statusBayar->statusbyr, array('class'=>'form-control','readonly')); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Tgl Buat</label>
                        <?php echo Form::text('created_at', $statusBayar->created_at, array('class' => 'form-control',
                        'readonly')); ?>

                    </div>
                    <div class="box-footer text-center">
                        <a href="<?php echo e(route('status-bayar.index')); ?>" class="btn btn-primary">Kembali</a>
                    </div>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
# AL Studio Digital Printing Application    
Management Application For Digital Printing Studio.

[![Build Status](https://travis-ci.org/hansenmakangiras/alstudioapp.svg?branch=master)](https://travis-ci.org/hansenmakangiras/alstudioapp)


TODO :

1. Master Details Order
2. Tambah Modul Promo
3. Laporan Harian, Bulanan, Tahunan
4. Widget Report

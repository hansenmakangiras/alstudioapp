<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Jenis Paket
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Create Jenis Paket
            <small>Data Jenis Paket</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('jenispaket.index')); ?>"><i class="fa fa-dashboard"></i> Jenis Paket</a></li>
            <li class="active">Create</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-8">
            <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Jenis Paket</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'jenispaket.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="jeniscetakid">Jenis Cetak</label>
                        <?php echo Form::select('jeniscetak',$jeniscetak, null, array('placeholder' => 'Pilih Jenis Cetak',
                        'class' =>'form-control select2','autofocus')); ?>

                    </div>
                    <div class="row">
                        <div class="col-xs-9">
                            <div class="form-group">
                                <label for="namapaket">Nama Paket</label>
                                <?php echo Form::text('nama_paket', null, array('placeholder' => 'Masukkan Nama Paket','class' =>
                                'form-control')); ?>

                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <label for="ukuran">Ukuran</label>
                                <?php echo Form::text('ukuran', null, array('placeholder' => 'cm','class' =>
                                'form-control')); ?>

                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <?php echo Form::text('deskripsi', null,array('placeholder' => 'deskripsi','class' =>
                        'form-control')); ?>

                    </div>
                    <div class="form-group">
                        <label for="hargajual">Harga Jual</label>
                        <?php echo Form::text('harga_jual',null, array('placeholder' => 'Masukkan harga jual','class' =>
                        'form-control','id'=> 'hargajual')); ?>

                    </div>
                    
                        
                            
                                
                                
                                
                            
                        
                        
                            
                                
                                
                                
                            
                        
                        
                            
                                
                                
                                
                            
                        
                    

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="<?php echo e(route('jenispaket.index')); ?>" class="btn btn-default">Kembali</a>
                    </div>
                </div>
            <?php echo Form::close(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        //Date picker
        // $('#tglAmbil').datepicker({
        //     autoclose: true,
        //     format: "yyyy-mm-dd"
        // })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    Jenis Cetakan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Jenis Cetakan
            <small>Data Master</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Small boxes (Stat box) -->
    
        
            
            
                
                    

                    
                
                
                    
                
                
            
        
        
        
            
            
                
                    

                    
                
                
                    
                
                
            
        
        
        
            
            
                
                    

                    
                
                
                    
                
                
            
        
        
        
            
            
                
                    

                    
                
                
                    
                
                
            
        
        
    


    <!-- /.row -->
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                <div class="box-header">
                    <button type="button" class="btn btn-success btn-flat btn-sm" data-toggle="modal"
                            data-target="#modal-tambah-jenis">
                        Tambah Jenis
                    </button>
                </div>
                <div class="modal fade" id="modal-tambah-jenis">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Tambah Jenis Cetakan</h4>
                            </div>
                            <form role="form" method="POST" action="<?php echo e(route('jenis-cetak.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="box-body">
                                        <div class="form-group">
                                            <label for="jeniscetak">Kode Jenis</label>
                                            <input type="text" class="form-control" id="kodejenis"
                                                   placeholder="Masukkan Kode Jenis" name="kode_jenis" required
                                                   autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="jeniscetak">Jenis Cetakan</label>
                                            <input type="text" class="form-control" id="jeniscetak"
                                                   placeholder="Masukkan jenis cetakan" name="jenis_cetak" required>
                                        </div>
                                        
                                            
                                            
                                                   
                                            
                                        
                                        
                                            
                                            
                                                   
                                            
                                        
                                    </div>
                                    <!-- /.box-body -->
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-default pull-left"
                                            data-dismiss="modal">Tutup</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="tbl-jenis-cetak" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode Jenis</th>
                            <th>Jenis Cetakan</th>
                            
                            <th>Operasi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($val->kode_jenis); ?></td>
                            <td><?php echo e($val->jenis_cetak); ?></td>
                            
                            
                            <td>
                                <a href="<?php echo e(route('jenis-cetak.edit',$val->id)); ?>" class="btn btn-primary
                                btn-xs btn-flat">Edit</a>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['jenis-cetak.destroy', $val->id],
                                    'style'=>'display:inline']); ?>

                                <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger btn-xs btn-flat']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>

        $('#tbl-jenis-cetak').DataTable({
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'autoWidth'   : true,
            "language": {
                "lengthMenu": "Tampilkan _MENU_ baris per page",
                "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
                //"info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "Data tidak tersedia",
                "infoFiltered": "(Filter dari _MAX_ total data)",
                "search" : "Pencarian",
                "paginate" : {
                    "first" : "Awal",
                    "last" : "Akhir",
                    "next" : "&gt;",
                    "previous" : "&lt;"
                }
            },
            "pagingType": "full_numbers",
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
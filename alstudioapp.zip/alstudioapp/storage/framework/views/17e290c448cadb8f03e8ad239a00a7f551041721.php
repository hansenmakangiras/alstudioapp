<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | List Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List Data Pemesanan
            <small>Order</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Pemesanan</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widget.alert', ['errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('order.create')); ?>" class="btn btn-success btn-sm"><i class="fa
                        fa-plus-circle"></i> Buat Pemesanan</a>
                </div>

                <div class="box-body">
                    <table id="tbl-order" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>No. Order</th>
                            <th>Jenis Cetakan</th>
                            <th>Jenis Paket</th>
                            <th>Pelanggan</th>
                            <th>Total Harga</th>
                            <th>Status Bayar</th>
                            <th>Status Pesanan</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        
                        
                            
                                
                                
                                
                            
                                
                                
                                
                                
                                
                                
                                
                                
                                    
                                    
                                    
                                    

                                    
                                
                                    

                                    
                                    
                                    
                                    
                                    

                                        
                                    
                                        
                                        
                                    
                                
                            
                        
                        
                    </table>

                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <?php echo $order->links(); ?>

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $('#tbl-order').DataTable({
            // 'dom': 'B<"clear">lfrtip',
            'processing'  : true,
            'serverSide'   : true,
            'ajax' : "<?php echo route('ajax.getOrderData'); ?>",
            'columns': [
                { data: 'id', name: 'id' },
                { data: 'orderid', name: 'orderid' },
                { data: 'cetakid', name: 'cetakid' },
                { data: 'jenispaketid', name: 'jenispaketid' },
                { data: 'pelangganid', name: 'pelangganid' },
                { data: 'total_harga', name: 'total_harga' },
                { data: 'status_bayar', name: 'status_bayar' },
                { data: 'status_order', name: 'status_order' },
                { data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            'order': [[1, 'asc']],
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'autoWidth'   : true,
            "language": {
                "lengthMenu": "Tampilkan _MENU_ baris per page",
                "zeroRecords": "Maaf, Data tidak ditemukan dalam database",
                //"info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "Data tidak tersedia",
                "infoFiltered": "(Filter dari _MAX_ total data)",
                "search" : "Pencarian",
                "paginate" : {
                    "first" : "Awal",
                    "last" : "Akhir",
                    "next" : "&gt;",
                    "previous" : "&lt;"
                }
            },
            "pagingType": "full_numbers",
            'buttons': true
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Mesin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Create Mesin
            <small>Master Data Mesin</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('mesin.index')); ?>"><i class="fa fa-dashboard"></i> Mesin</a></li>
            <li class="active">Create</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-6">
            <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Mesin</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::open(array('route' => 'mesin.store','method'=>'POST')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Nama Mesin</label>
                        <?php echo Form::text('nama_mesin', null, array('placeholder' => 'Nama Mesin','class' =>
                        'form-control','autofocus')); ?>

                    </div>
                    <div class="form-group">
                        <label for="iTipeMesin">Tipe Mesin</label>
                        <?php echo Form::text('tipe_mesin', null, array('placeholder' => 'Tipe Mesin','class' =>
                        'form-control','id'=>'iTipeMesin')); ?>

                    </div>
                    <div class="form-group">
                        <label for="iHarga">Harga</label>
                        <?php echo Form::text('hpp', null,array('placeholder' => 'Harga jual','class' => 'form-control',
                        'id'=> 'iHarga')); ?>

                    </div>

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="<?php echo e(route('mesin.index')); ?>" class="btn btn-default">Kembali</a>
                    </div>
                </div>
            <?php echo Form::close(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('message'); ?>
    <p class="login-box-msg">Silahkan login untuk menggunakan aplikasi</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group has-feedback">
            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                   placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group has-feedback">
            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password" name="password" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>

        </div>
        <div class="row">
            <div class="col-xs-8">
                <div class="checkbox icheck">
                    <label>
                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        Ingat Saya
                    </label>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-xs-4">
                <button type="submit" class="btn btn-primary btn-block btn-flat">Masuk</button>
            </div>
            <!-- /.col -->
        </div>
    </form>
    <div class="social-auth-links text-center">
        <p>- OR -</p>
        <a href="<?php echo e(route('password.request')); ?>" class="btn btn-block btn-social btn-success btn-flat"><i class="fa
        fa-lock"></i>Lupa Password</a>
        
        
            
            
    </div>
    <!-- /.social-auth-links -->

    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle'); ?>
    | Status Cetak
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Ubah Status Cetak
            <small>Data Status Cetak</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('status-cetak.index')); ?>"><i class="fa fa-dashboard"></i> Status Cetak</a></li>
            <li class="active">Ubah</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row">
        <div class="col-xs-6">
            <?php echo $__env->make('widget.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Ubah Status Cetak</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::model($statusCetak, ['method' => 'PATCH','route' => ['status-cetak.update',
                $statusCetak->id]]); ?>

                <div class="box-body">
                    <div class="form-group">
                        <label for="name">Status Cetak</label>
                        <?php echo Form::text('statuscetak', null, array('placeholder' => 'Status Cetak','class' =>
                        'form-control','autofocus')); ?>

                    </div>

                    <div class="box-footer text-center">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('status-cetak.index')); ?>" class="btn btn-default">Kembali</a>
                    </div>
                </div>
            <?php echo Form::close(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>